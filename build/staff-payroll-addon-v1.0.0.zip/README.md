# Staff Payroll Addon

This addon enables staff payroll features:

- Staff directory and records
- Salary payments
- Payslip generation
- Staff registration link flow

## Installation

1. Open Admin -> System -> Addons.
2. Upload the addon ZIP package.
3. Activate `staff-payroll`.

The ZIP package must include `addon.json` at archive root.
